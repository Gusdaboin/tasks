<?php
namespace ClassPross;

/**
 * AccountLink
 */
class AccountLink
{

  var $link;
  function __construct()
  {
  
  }
}
