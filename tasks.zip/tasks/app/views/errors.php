<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>ERROR</title>
    <link rel="stylesheet" href="/css/app.css">
  </head>
  <body>
    <div class="neo-grid">
      <div class="col-lg-12 text-center">
        <h1>ERROR 404</h1>
        <h4>NOT FOUND</h4>
      </div>
    </div>
  </body>
</html>
