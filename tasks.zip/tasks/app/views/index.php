<div class="container">
  <div class="row my-5">
    <div class="col-md-6 mx-auto text-center">
      <h1>Portal de Tareas</h1>
      <i class="ion-ios-list-outline d-block display-4 my-5" style="font-size:96px;"></i>
      <a class="btn-gold" href="/login">Inicia Sesión</a>
    </div>
  </div>
</div>
