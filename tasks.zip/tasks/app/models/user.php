<?php
namespace App\Models;
use ClassPross\DB as DB;

/**
 * User model
 */
class User extends DB
{
  var $table='users';

}
