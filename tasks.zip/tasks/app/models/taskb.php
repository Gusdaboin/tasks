<?php
namespace App\Models;
use ClassPross\DB as DB;

/**
 * Task Backup model
 */
class Taskb extends DB
{
  var $table='tasks_backup';
}
