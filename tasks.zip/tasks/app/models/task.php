<?php
namespace App\Models;
use ClassPross\DB as DB;

/**
 * User model
 */
class Task extends DB
{
  var $table='tasks';
}
