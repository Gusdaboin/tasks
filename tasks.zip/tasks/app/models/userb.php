<?php
namespace App\Models;
use ClassPross\DB as DB;

/**
 * User Backup model
 */
class Userb extends DB
{
  var $table='users_backup';

}
